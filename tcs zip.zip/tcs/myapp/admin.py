from django.contrib import admin
from .models import Customer, Add_prob, Bidding


class AdminCustomer(admin.ModelAdmin):
    list_display = ['first_name', 'last_name', 'email', 'gender', 'phone', 'blood_group', 'dob']

class AdminProb(admin.ModelAdmin):
    list_display = ['customer_id', 'email', 'customer_name', 'problem', 'details']

class AdminBidding(admin.ModelAdmin):
    list_display = ['project', 'price', 'email']

# Register your models here.

admin.site.register(Customer, AdminCustomer)
admin.site.register(Add_prob, AdminProb)
admin.site.register(Bidding, AdminBidding)


