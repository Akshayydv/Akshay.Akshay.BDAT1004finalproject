from django.urls import path
from .views import *


urlpatterns = [
    path('base/', base),
    path('', index, name="index"),
    path('signup/', signup),
    path('signup_landing/', signup_landing),
    path('login/', login, name="login"),
    path('account_home/', account_home, name="account_home"),
    path('logout/', logout),
    path('add_prob/', add_prob),
    path('all_details/', all_details),
    path('all_projects/', all_projects),
    path('charts/', charts)
]
from datetime import timedelta
from django.db.models.functions import Now
