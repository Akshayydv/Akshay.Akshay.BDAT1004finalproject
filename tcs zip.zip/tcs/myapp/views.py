from ast import Add
from django.shortcuts import render, redirect
from requests import request
from .models import Customer, Add_prob, Bidding, MyModel
from django.contrib.auth.hashers import make_password, check_password

# Create your views here.

def base(request):
    return render(request, 'base.html')


def index(request):
    email = request.session.get('email')
    customer = Customer.get_customer_by_email(email)
    if customer:
        first_name = customer.first_name
        last_name = customer.last_name
        print(first_name)
        values = {
        'first_name' : first_name,
        'last_name' : last_name
        }
        return render(request, 'index.html', values)
    else:
        print("Sorry")
        return render(request, 'index.html')

def validateCustomer(customer):
    error_message = None
    if not customer.first_name:
        error_message = 'First name is required!'
    elif len(customer.first_name) < 4:
        error_message = 'First name must  be 4 char long!'
    if not customer.last_name:
        error_message = 'Last name is required!'
    elif len(customer.last_name) < 4:
        error_message = 'Last name must  be 4 char long!'
    elif len(customer.email) < 5:
        error_message = 'Email name must  be 5 char long!'
    if not customer.phone:
        error_message = 'Phone is required!'
    elif len(customer.phone) < 10:
        error_message = 'Phone must  be 10 char long!'
    if not customer.password:
        error_message = 'Password is required!'
    elif len(customer.password) < 4:
        error_message = 'Password must  be 5 char long!'
    elif customer.isExists():
        error_message = 'Email Address Already Registered'

    return error_message

def account_home(request):
    print("you are : ", request.session.get('email'))
    email = request.session.get('email')
    customer = Customer.get_customer_by_email(email)
    print(customer)
    print(customer.first_name)

    name = customer.first_name
    blood_group = customer.blood_group
    gender = customer.gender


    print(name)
    value = {
        'name' : name,
        'blood_group' : blood_group,
        'gender' : gender
    }
    return render(request, 'account_home.html', value)


def signup(request):
    if request.method == 'GET':
        return render(request, 'signup.html')
    else:
        postData = request.POST
        print(postData)
        first_name = postData.get('firstname')
        last_name = postData.get('lastname')
        email = postData.get('email')
        phone = postData.get('phone')
        password = postData.get('password')
        blood_group = postData.get('blood_group')
        gender = postData.get('gender')
        dob = postData.get('dob')
        #validation
        value = {
            'first_name' : first_name,
            'last_name' : last_name,
            'email' : email,
            'phone' : phone,
            'blood_group' : blood_group,
            'gender' : gender,
            'dob' : dob,
        }

        error_message = None
        customer = Customer(first_name=first_name,
                            last_name=last_name,
                            email=email,
                            phone=phone,
                            password=password,
                            blood_group=blood_group,
                            gender=gender,
                            dob=dob)
        error_message = validateCustomer(customer)

        #saving
        if not error_message:
            print(first_name, last_name)
            customer.password = make_password(customer.password)
            customer.register()
            return redirect('login')
        else:
            data = {
                'error' : error_message,
                'values' : value
            }
            return render(request, 'signup.html', data)

def signup_landing(request):
    return render(request, 'signup_landing.html')

def login(request):
    if request.method == 'GET':
        return render(request, 'login.html')
    else:
        email = request.POST.get('email')
        password = request.POST.get('password')
        customer = Customer.get_customer_by_email(email)
        error_message = None
        if customer:
            flag = check_password(password, customer.password)
            if flag:
                request.session['customer'] = customer.id
                request.session['email'] = customer.email
                return redirect('account_home')
            else:
                error_message = 'Email or password invalid'

        else:
            error_message = 'Email or Password invalid!!'

        print(customer)
        print(email, password)
        return render(request, 'login.html', {'error' : error_message})

def logout(request):
    request.session.clear()
    return redirect('login')


def add_prob(request):
    if request.method == 'GET':
        return render(request, 'add_prob.html')
    else:
        # changes
        email = request.session.get('email')
        customer = Customer.get_customer_by_email(email)
        customer_name = customer.first_name
        problem = request.POST.get('problem')
        details = request.POST.get('details')
        # report = request.POST.get('report')

        value = {
            'customer' : customer,
            'customer_name' : customer_name,
            'problem' : problem,
            'details' : details,
            # 'report' : report,
            'email' : email,
        }

        data = {
            'values' : value
        }

        add_prob = Add_prob(customer=customer,
                            customer_name=customer_name,
                            problem=problem,
                            details=details,
                            # report=report,
                            email=email,)
        add_prob.register()
        return render(request, 'account_home.html', data)    

def all_details(request):
    email = request.session.get('email')
    customer = Customer.get_customer_by_email(email)
    name = customer.first_name
    list = Add_prob.list_of_problems_with_email(email)
    print(f"list: {list}")
    list_of_problems = []
    number_list = []
    for i in range (0, len(list)):
        list_of_problems.append(list[i].problem)

    print(list_of_problems[0])
    print(f"List of problems: {list_of_problems} ")
    print(f"Hi {name}")

    data = {
        'problems' : list_of_problems,
        'numbers' : number_list,
        'details' : customer,
        'name' : name
    }
    return render(request, 'all_details.html', data)



def all_projects(request):
    if request.method == 'GET':
        email = request.session.get('email')
        customer = Customer.get_customer_by_email(email)
        list_of_projects = Add_prob.get_all_details()
        print(list_of_projects)
        list_of_description = Add_prob.get_all_description()

        fin_list_proj = []
        # for i in range(0, len(list_of_projects)):
        #     fin_list_proj.append(list_of_projects[i].problem)
        final_list = zip(list_of_projects, list_of_description)
        data = {
            'list_proj' : final_list
        }
        return render(request, 'all_projects.html', data)

    else:
        project = request.POST.get('project')
        price = request.POST.get('price')
        email = request.POST.get('email')

        value = {
            'project' : project,
            'price' : price,
            'email' : email
        }
        data = {
            'values' : value
        }
        bidding = Bidding(project=project,
                          price=price,
                          email=email
        )
        bidding.register()
        return render(request, 'account_home.html', data)

def charts(request):
    return render(request,'charts.html',{'item':Bidding.objects.all()})

