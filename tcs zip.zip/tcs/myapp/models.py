from django.db import models

# Create your models here.
from django.db import models
from datetime import *


# Create your models here.

class Customer(models.Model):

    class Meta:
        verbose_name_plural = 'customers'

    #customer_id = models.ForeignKey(Second_form, on_delete=models.CASCADE)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email = models.EmailField()
    phone = models.CharField(max_length=15)
    password = models.CharField(max_length=500)
    blood_group = models.CharField(max_length=50, default="A Positive")
    gender = models.CharField(max_length=50, default="Other")
    dob = models.DateField(default=date.today)

    def register(self):
        self.save()

    @staticmethod
    def get_customer_by_email(email):
        try:
            return Customer.objects.get(email=email)
        except:
            return False

    @staticmethod
    def get_all_details():
        return Customer.objects.all()

    @staticmethod
    def get_all_details_by_customerid(customer_id):
        return Customer.objects.filter(customer = customer_id)




    def isExists(self):
        if Customer.objects.filter(email=self.email):
            return True

        return False


class Add_prob(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, default=1, related_name='customers')
    customer_name = models.CharField(max_length=50, default='NA')
    problem = models.CharField(max_length=50)
    # report = models.ImageField(upload_to='uploads/report')
    # new 
    details = models.CharField(max_length=1000, default='NA')
    email = models.EmailField(default='deepak@gmail.com')
    print("customer:", customer)

    def register(self):
        self.save()

    @staticmethod
    def get_all_problems_with_email(email):
        try:
            return Add_prob.objects.get(email=email)
        except:
            return False

    @staticmethod
    def list_of_problems_with_email(email):
        list = Add_prob.objects.filter(email=email)
        return list

    @staticmethod
    def get_all_details():
        list_of_problems = Add_prob.objects.values('problem')
        print(list_of_problems)
        return list_of_problems

    @staticmethod
    def get_all_description():
        list_of_description = Add_prob.objects.values('details')
        return list_of_description

    def get_project_details_with_name(name):
        values = Add_prob.objects.filter(name=name).values('details')
        return values

class Bidding(models.Model):
    project = models.CharField(max_length=100)
    price = models.CharField(max_length=50)
    email = models.EmailField()

    def register(self):
        self.save()

class MyModel(models.Model):
    timestamp = models.DateTimeField(auto_now_add=True, db_index=True)    